#Shane Doherty
#This program chooses either website or wizard mode to build the HTML(s)

import sys
import turtle
import website_mode
import wizard_mode

def main():
    if len(sys.argv) == 1:
        wizard_mode.main()
    else:
        website_mode.main()
#This function runs either wizard mode or website mode based on the number of parameters provided in sys.argv
#Pre-conditions: Nothing occurs
#Post-conditions: One of the two website builders are run

if __name__ == '__main__':
    main()


