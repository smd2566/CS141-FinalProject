#Shane Doherty
#This program builds HTMLS in website mode
import turtle
import os.path
from os import path
import sys
FONTS = ["Arial", "Comic Sans MS", "Lucida Grande", "Tahoma", "Verdana", "Helvetica", "Times New Roman"]

def template_build():
    with open("style_template.txt", "+r") as file:
        with open("html.txt", "+w") as file2:
            file2.write("<!DOCTYPE html>")
            file2.write("<html>")
            file2.write("<head>")
            for line in file:
                file2.write(line)
            file2.write("<title>")
            file2.write("@WEBSITETITLE")
            file2.write("</title>")
            file2.write("</head>")
            file2.write("<body>")
            file2.write("<!--@LINKS-->")
            file2.write("<h1>")
            file2.write("@WEBSITETITLE")
            file2.write("</h1>")
            file2.write("<h2>")
            file2.write("@PARAGRAPHTITLE")
            file2.write("</h2>")
            file2.write("<p>")
            file2.write("@PARAGRAPHCONTENT")
            file2.write("</p>")
            file2.write("<img src = @IMAGE>")
#This function builds a new template based on the provided style template
#Pre-conditions: The base style template remains
#Post-conditions: A new custom template is written to a new file

def color_display(color_input):
    color_set = color_set_sort()
    if color_input not in color_set:
        while color_input not in color_set:
            color_input = input("Invalid Color, please follow the format:")
        return color_input
    else:
        color = color_input
        return color
#This function checks if the provided colors exist within the colors.txt file list
#Pre-conditions: The colors are not checked
#Post-conditions: The colors are checked and an error is returned if the color is invalid

def color_set_sort():
    color_set = set()
    color_file = open("colors.txt")
    for line in color_file:
        line = line.strip()
        color_set.add(str(line))
    color_file.close()
    return color_set
#This function creates a list of colors based on the lines within colors.txt
#Pre-conditions: No color list is created
#Post-conditions: A color list is created and returned

def font_display(font_decision):
    font_number_set = {0, 1, 2, 3, 4, 5, 6}
    if font_decision == 'yes' or font_decision == 'Yes' or font_decision == 'YES' or font_decision == '':
        print("The font window will now be displayed, please close the window when you have made your selection")
        font_demonstration()
        print("Choose a font by its number:")
        print("0: Arial, size 14")
        print("1: Comic Sans MS, size 14")
        print("2: Lucida Grande, size 14")
        print("3: Tahoma, size 14")
        print("4: Verdana, size 14")
        print("5: Helvetica, size 14")
        print("6: Times New Roman, size 14")
        font_number = input("Please enter a number: ")
        if int(font_number) not in font_number_set:
            while int(font_number) not in font_number_set:
                font_number = input("Invalid number, please enter in the range of 0-6:")
        font_selection = FONTS[int(font_number)]
        return font_selection
    elif font_decision == 'no' or font_decision =='No' or font_decision == 'NO':
        print("The font window will not be displayed")
        print("Choose a font by its number: ")
        print("0: Arial, size 14")
        print("1: Comic Sans MS, size 14")
        print("2: Lucida Grande, size 14")
        print("3: Tahoma, size 14")
        print("4: Verdana, size 14")
        print("5: Helvetica, size 14")
        print("6: Times New Roman, size 14")
        font_number = input("Please enter a number: ")
        if int(font_number) not in font_number_set:
            while int(font_number) not in font_number_set:
                font_number = input("Invalid number, please enter in the range of 0-6:")
        font_selection = FONTS[int(font_number)]
        return font_selection
#This function calls a font window to appear if the user answers 'yes', and allows the user to pick a font number
#Pre-conditions: The user is not provided an option to select the font type
#Post-conditions: The user is allowed to select the font type

def font_demonstration():
    turtle.setup(200, 200)
    turtle.up()
    y = 70
    turtle.setposition(-85,y)
    for i in FONTS:
        turtle.speed(1)
        style = (i, 14)
        turtle.write(i, font = style)
        turtle.up()
        y = y - 20
        turtle.setposition(-85, y)
        turtle.down()
    turtle.hideturtle()
    turtle.done()
#This function creates a font display window with turtle
#Pre-conditions: The font window is not created or displayed
#Post-conditions: The font window is created and displayed to the user

def input_management():
    print("Background Color")
    background_color_input = input("Choose the name of a color, or in format '#XXXXXX': ")
    background_color = color_display(background_color_input)

    print("You will now choose a font")
    font_decision = input("Do you want to see what the fonts look like? Answer 'yes' or 'no': ")
    font_name = font_display(font_decision)

    print("Paragraph Text color")
    text_color_input = input("Choose the name of a text color, or in format '#XXXXXX': ")
    text_color = color_display(text_color_input)

    print("Heading color")
    heading_color_input = input("Choose the name of a heading color, or in format '#XXXXXX': ")
    heading_color = color_display(heading_color_input)
    return background_color, font_name, text_color, heading_color
#This function allows the user to choose a variety of options for their custom website
#Pre-conditions: No options are given to the user
#Post-conditions: The user is able to pick a background color, a font type, a font color and a heading color

def html_writer(filename, list_of_links):
    paragraph_tuple = input_management()
    background_color = paragraph_tuple[0]
    font_name = paragraph_tuple[1]
    text_color = paragraph_tuple[2]
    heading_color = paragraph_tuple[3]
    mega_list =[]
    with open((filename) + ".html", "w") as file3:
        with open("html.txt", "+r") as file2:
            with open((filename), "+r") as file:
                website_title = file.readline().strip()
                print(website_title)
                paragraph_content_list = []
                for line in file:
                    if "!new_paragraph" in line:
                        mega_list.append(paragraph_content_list)
                        paragraph_content_list = []
                    elif "!title" in line:
                        line = line.strip("!title ").strip()
                        paragraph_content_list.append(line)
                    elif "!image" in line:
                        line = line.strip()
                        splitted = line.split()
                        paragraph_content_list.append(splitted[1])
                    elif not line.strip():
                        if path.exists(paragraph_content_list[-1]) == False:
                            paragraph_content_list.append("")
                    else:
                        paragraph_content_list.append(line.strip())
                        if path.exists(paragraph_content_list[-1]) == False:
                            paragraph_content_list.append("")
                mega_list.append(paragraph_content_list)
            del(mega_list[0])
            first_paragraph_information = mega_list[0]
            for line in file2:
                if "@BACKCOLOR" in line:
                    line = line.replace("@BACKCOLOR", background_color)
                if "@HEADCOLOR" in line:
                    line = line.replace("@HEADCOLOR", heading_color)
                if "@FONTSTYLE" in line:
                    line = line.replace("@FONTSTYLE", font_name)
                if "@FONTCOLOR" in line:
                    line = line.replace("@FONTCOLOR", text_color)
                if "@WEBSITETITLE" in line:
                    line = line.replace("@WEBSITETITLE", website_title)
                if "@PARAGRAPHTITLE" in line:
                    line = line.replace("@PARAGRAPHTITLE", first_paragraph_information[0])
                if "<!--@LINKS-->" in line:
                    line = line.replace("<!--@LINKS-->", list_of_links)
                if "@PARAGRAPHCONTENT" in line:
                    string = ""
                    for i in range(1, len(first_paragraph_information)-1):
                        string+= "" + first_paragraph_information[i]
                    line = line.replace("@PARAGRAPHCONTENT", string)
                if "@IMAGE" in line:
                    if first_paragraph_information[len(first_paragraph_information)-1] == "":
                        pass
                    elif first_paragraph_information[len(first_paragraph_information)-1 != ""]:
                        line = line.replace("@IMAGE", str(first_paragraph_information[len(first_paragraph_information)-1]))
                file3.write(line)
            for i in range(1, len(mega_list)):
                file3.write("<h2>" + mega_list[i][0] + "</h2>")
                temp = ""
                for e in range(1, len(mega_list[i]) - 1):
                    temp +=mega_list[i][e]
                file3.write("<p>" + temp + "</p>")
                if mega_list[i][len(mega_list[i])-1] != "":
                    file3.write("<img src = " + mega_list[i][len(mega_list[i])-1] + ">")
            file3.write("</body>")
            file3.write("</html>")
#This function replaces and writes in values and strings to create the final HTML file based on the given text files
#Pre-conditions: No HTML page is created
#Post-conditions: An HTML page is created and written to a new file

def file_list_builder():
    file_list = []
    for i in range(1, len(sys.argv)):
        file_list.append(sys.argv[i])
    return(file_list)
#This function builds a list based on the items in sys.argv for the links in the website
#Pre-conditions: No list is built
#Post-conditions: A list of filenames is built

def html_runner():
    file_list = file_list_builder()
    string = ""
    for i in file_list:
        string+= "<a href=" + (i + ".html")  +">" + str(i) + "</a> "
    for i in file_list:
        html_writer(i, string)
#This function builds a string of links, and runs html_writer based on the current index of the paragraph list
#Pre-conditions: Nothing occurs
#Post-conditions: An HTML page is created with links

def main():
    template_build()
    html_runner()
#This function builds the new template and runs the entire program
#Pre-conditions: Nothing occurs
#Post-conditions: An entire set of HTML pages are created based on the number of given sys.argv arguments

if __name__ == '__main__':
    main()
